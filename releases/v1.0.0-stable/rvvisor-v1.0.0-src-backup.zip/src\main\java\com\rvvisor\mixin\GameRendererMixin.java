package com.rvvisor.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.rvvisor.RVVisorMod;
import com.rvvisor.core.optics.LensSettings;
import com.rvvisor.render.VRRenderEngine;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.GameRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Shadow
    @Final
    private Minecraft minecraft;

    @Shadow
    @Final
    private Camera mainCamera;

    @Shadow
    public abstract void renderLevel(DeltaTracker deltaTracker);

    @Shadow
    public abstract Matrix4f getProjectionMatrix(double fov);

    private boolean isInsideStereoPass = false;

    /**
     * Master Stereo Render Loop:
     * When inside a Minecraft world, executes Left & Right Eye passes using MainRenderTarget,
     * copies native block/entity textures with shaders, renders Pause Menu / GUI screens,
     * and submits to SteamVR / Virtual Desktop.
     */
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void rvvisor$renderStereoPipeline(DeltaTracker deltaTracker, boolean renderLevel, CallbackInfo ci) {
        RVVisorMod mod = RVVisorMod.getInstance();
        if (mod == null || !mod.isVrActive() || this.isInsideStereoPass) {
            return;
        }

        // Only hijack the render pipeline when a level is actually loaded
        if (this.minecraft.level == null) {
            return;
        }

        VRRenderEngine engine = mod.getRenderEngine();
        if (engine == null) return;

        try {
            this.isInsideStereoPass = true;
            float partialTicks = deltaTracker.getGameTimeDeltaPartialTick(false);
            int windowWidth = this.minecraft.getWindow().getWidth();
            int windowHeight = this.minecraft.getWindow().getHeight();

            // 1. Poll VR tracking and update poses
            engine.onRenderFrameStart();

            // 2. EYE PASS 0: Left Eye
            engine.beginEyePass(LensSettings.EYE_LEFT, partialTicks);

            if (renderLevel) {
                this.renderLevel(deltaTracker);
            }
            this.rvvisor$renderCurrentScreen(deltaTracker, partialTicks);
            engine.copyMainTargetToEyeFbo(LensSettings.EYE_LEFT, this.minecraft.getMainRenderTarget());
            engine.endEyePass();

            // 3. EYE PASS 1: Right Eye
            engine.beginEyePass(LensSettings.EYE_RIGHT, partialTicks);
            if (renderLevel) {
                this.renderLevel(deltaTracker);
            }
            this.rvvisor$renderCurrentScreen(deltaTracker, partialTicks);
            engine.copyMainTargetToEyeFbo(LensSettings.EYE_RIGHT, this.minecraft.getMainRenderTarget());
            engine.endEyePass();

            // 4. Submit stereo textures to SteamVR / OpenVR compositor and render spectator mirror
            engine.finishAndSubmitFrame(windowWidth, windowHeight);

            // Cancel standard flat mono render pass
            ci.cancel();
        } catch (Throwable t) {
            RVVisorMod.LOGGER.error("[RV-Visor] Error during VR stereo render pass", t);
        } finally {
            this.isInsideStereoPass = false;
        }
    }

    private void rvvisor$renderCurrentScreen(DeltaTracker deltaTracker, float partialTicks) {
        try {
            int guiWidth = this.minecraft.getWindow().getGuiScaledWidth();
            int guiHeight = this.minecraft.getWindow().getGuiScaledHeight();

            // CRITICAL: Force the viewport to the VR Eye resolution (MainRenderTarget)
            // Sometimes vanilla or other mods reset the viewport to the desktop physical window size (1920x1080)
            // causing the GUI and anything left in the buffer to render in a small box at the bottom left!
            com.mojang.blaze3d.systems.RenderSystem.viewport(0, 0, this.minecraft.getMainRenderTarget().width, this.minecraft.getMainRenderTarget().height);

            // Explicitly set 2D orthographic projection matrix for GUI and HUD elements
            Matrix4f ortho = new Matrix4f().setOrtho(0.0F, (float) guiWidth, (float) guiHeight, 0.0F, 1000.0F, 21000.0F);
            com.mojang.blaze3d.systems.RenderSystem.setProjectionMatrix(ortho, com.mojang.blaze3d.vertex.VertexSorting.ORTHOGRAPHIC_Z);

            // Clear depth buffer and disable depth testing so UI widgets render cleanly above 3D world geometry
            com.mojang.blaze3d.systems.RenderSystem.clear(org.lwjgl.opengl.GL11.GL_DEPTH_BUFFER_BIT, Minecraft.ON_OSX);
            com.mojang.blaze3d.platform.GlStateManager._disableDepthTest();
            com.mojang.blaze3d.systems.RenderSystem.enableBlend();
            com.mojang.blaze3d.systems.RenderSystem.defaultBlendFunc();

            GuiGraphics guiGraphics = new GuiGraphics(this.minecraft, this.minecraft.renderBuffers().bufferSource());

            if (this.minecraft.screen != null) {
                int mouseX = (int) (this.minecraft.mouseHandler.xpos() * (double) guiWidth / (double) this.minecraft.getWindow().getScreenWidth());
                int mouseY = (int) (this.minecraft.mouseHandler.ypos() * (double) guiHeight / (double) this.minecraft.getWindow().getScreenHeight());
                this.minecraft.screen.renderWithTooltip(guiGraphics, mouseX, mouseY, partialTicks);
            } else if (this.minecraft.gui != null) {
                this.minecraft.gui.render(guiGraphics, deltaTracker);
            }

            guiGraphics.flush();
            com.mojang.blaze3d.platform.GlStateManager._enableDepthTest();
        } catch (Throwable t) {
            RVVisorMod.LOGGER.warn("[RV-Visor] Failed during screen render pass: {}", t.getMessage());
        }
    }

    @Inject(method = "getProjectionMatrix", at = @At("HEAD"), cancellable = true)
    private void rvvisor$overrideProjectionMatrix(double fov, CallbackInfoReturnable<Matrix4f> cir) {
        RVVisorMod mod = RVVisorMod.getInstance();
        if (mod != null && mod.isVrActive()) {
            VRRenderEngine engine = mod.getRenderEngine();
            if (engine != null && engine.isRenderingVR()) {
                cir.setReturnValue(engine.getEyeProjectionMatrix(0.05f, 1000.0f));
            }
        }
    }

    @Inject(method = "bobView", at = @At("HEAD"), cancellable = true)
    private void rvvisor$cancelBobView(PoseStack poseStack, float partialTicks, CallbackInfo ci) {
        RVVisorMod mod = RVVisorMod.getInstance();
        if (mod != null && mod.isVrActive() && this.minecraft.level != null) {
            // Cancel camera view bobbing in VR to eliminate motion sickness
            ci.cancel();
        }
    }

    @Inject(method = "bobHurt", at = @At("HEAD"), cancellable = true)
    private void rvvisor$cancelBobHurt(PoseStack poseStack, float partialTicks, CallbackInfo ci) {
        RVVisorMod mod = RVVisorMod.getInstance();
        if (mod != null && mod.isVrActive() && this.minecraft.level != null) {
            // Cancel damage view tilt in VR
            ci.cancel();
        }
    }

    @Inject(method = "renderItemInHand", at = @At("HEAD"), cancellable = true)
    private void rvvisor$renderVRWorldElements(Camera camera, float partialTicks, Matrix4f projectionMatrix, CallbackInfo ci) {
        RVVisorMod mod = RVVisorMod.getInstance();
        if (mod != null && mod.isVrActive() && this.minecraft.level != null) {
            VRRenderEngine engine = mod.getRenderEngine();
            if (engine != null) {
                // DIAGNOSTIC LOGGING BEFORE HAND RENDER
                int[] viewport = new int[4];
                int[] scissor = new int[4];
                boolean scissorEnabled = org.lwjgl.opengl.GL11.glIsEnabled(org.lwjgl.opengl.GL11.GL_SCISSOR_TEST);
                org.lwjgl.opengl.GL11.glGetIntegerv(org.lwjgl.opengl.GL11.GL_VIEWPORT, viewport);
                org.lwjgl.opengl.GL11.glGetIntegerv(org.lwjgl.opengl.GL11.GL_SCISSOR_BOX, scissor);
                int drawFbo = org.lwjgl.opengl.GL11.glGetInteger(org.lwjgl.opengl.GL30.GL_DRAW_FRAMEBUFFER_BINDING);
                RVVisorMod.LOGGER.info("[DIAGNOSTIC] BEFORE renderHands - Viewport: {} {} {} {}, ScissorEnabled: {}, ScissorBox: {} {} {} {}, DrawFBO: {}", 
                    viewport[0], viewport[1], viewport[2], viewport[3], scissorEnabled, scissor[0], scissor[1], scissor[2], scissor[3], drawFbo);

                // Render 6-DOF Hand models, held items, and 3D Crosshair in world space
                engine.renderVRWorldElements(camera, partialTicks, projectionMatrix);
                // CRITICAL: Flush the buffer source here so hands are drawn with 3D projection and depth!
                this.minecraft.renderBuffers().bufferSource().endBatch();
                
                // DIAGNOSTIC LOGGING AFTER HAND RENDER
                org.lwjgl.opengl.GL11.glGetIntegerv(org.lwjgl.opengl.GL11.GL_VIEWPORT, viewport);
                org.lwjgl.opengl.GL11.glGetIntegerv(org.lwjgl.opengl.GL11.GL_SCISSOR_BOX, scissor);
                scissorEnabled = org.lwjgl.opengl.GL11.glIsEnabled(org.lwjgl.opengl.GL11.GL_SCISSOR_TEST);
                drawFbo = org.lwjgl.opengl.GL11.glGetInteger(org.lwjgl.opengl.GL30.GL_DRAW_FRAMEBUFFER_BINDING);
                RVVisorMod.LOGGER.info("[DIAGNOSTIC] AFTER renderHands - Viewport: {} {} {} {}, ScissorEnabled: {}, ScissorBox: {} {} {} {}, DrawFBO: {}", 
                    viewport[0], viewport[1], viewport[2], viewport[3], scissorEnabled, scissor[0], scissor[1], scissor[2], scissor[3], drawFbo);
            }
            // Cancel 2D vanilla arm rendering so VR 6-DOF hand renderer takes full control
            ci.cancel();
        }
    }
}
