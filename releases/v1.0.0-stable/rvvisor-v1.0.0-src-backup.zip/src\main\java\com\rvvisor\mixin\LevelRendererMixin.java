package com.rvvisor.mixin;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.rvvisor.RVVisorMod;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.client.renderer.SectionOcclusionGraph;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LevelRenderer.class)
public abstract class LevelRendererMixin {
    @Shadow
    @Final
    private SectionOcclusionGraph sectionOcclusionGraph;

    @Shadow
    @Nullable
    private PostChain transparencyChain;

    @Unique
    private PostChain rvvisor$savedTransparencyChain;

    @Inject(method = "renderLevel", at = @At("HEAD"))
    private void rvvisor$beforeRenderLevel(DeltaTracker deltaTracker, boolean renderBlockOutline, Camera camera, GameRenderer gameRenderer, LightTexture lightTexture, Matrix4f modelViewMatrix, Matrix4f projectionMatrix, CallbackInfo ci) {
        RVVisorMod mod = RVVisorMod.getInstance();
        if (mod != null && mod.isVrActive()) {
            this.sectionOcclusionGraph.invalidate();
            if (this.sectionOcclusionGraph instanceof SectionOcclusionGraphAccessor accessor) {
                accessor.getNeedsFrustumUpdate().set(true);
            }
            // Note: We NO LONGER disable transparencyChain. We let Fabulous graphics composite correctly using depth!
        }
    }

}
