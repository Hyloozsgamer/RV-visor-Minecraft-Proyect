package com.rvvisor.mixin;

import com.rvvisor.RVVisorMod;
import com.rvvisor.render.VRRenderEngine;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public abstract class MinecraftMixin {
    @Shadow
    @Final
    public GameRenderer gameRenderer;


    @Inject(method = "runTick", at = @At("HEAD"))
    private void rvvisor$onFrameStart(boolean renderLevel, CallbackInfo ci) {
        RVVisorMod mod = RVVisorMod.getInstance();
        if (mod != null && mod.isVrActive()) {
            VRRenderEngine engine = mod.getRenderEngine();
            if (engine != null) {
                engine.onRenderFrameStart();
            }
        }
    }

    @Inject(method = "destroy", at = @At("HEAD"))
    private void rvvisor$onDestroy(CallbackInfo ci) {
        RVVisorMod mod = RVVisorMod.getInstance();
        if (mod != null) {
            if (mod.getRenderEngine() != null) {
                mod.getRenderEngine().destroy();
            }
            if (mod.getVrProvider() != null) {
                mod.getVrProvider().shutdown();
            }
        }
    }

    /**
     * Disables the Fabulous graphics post-chain processing in VR.
     * This forces Minecraft to use standard Forward Rendering for water/translucency,
     * which inherently works flawlessly with our Stereo VR Framebuffers,
     * mimicking Vivecraft's "RenderVrFast" behavior.
     */
    @Inject(method = "useShaderTransparency", at = @At("HEAD"), cancellable = true)
    private static void rvvisor$disableFabulousInVR(org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable<Boolean> cir) {
        RVVisorMod mod = RVVisorMod.getInstance();
        if (mod != null && mod.isVrActive()) {
            cir.setReturnValue(false);
        }
    }
}
