package com.rvvisor.render;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.rvvisor.RVVisorMod;
import com.rvvisor.core.data.VRTrackingContext;
import com.rvvisor.core.optics.LensSettings;
import com.rvvisor.core.provider.IVRProvider;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;

/**
 * Master VR Rendering Engine - Corregido
 * Renderiza directo a cada ojo, con blending de agua y translucidos, y control dinamico de resolucion.
 */
public class VRRenderEngine {
    private final IVRProvider vrProvider;
    private final VRTrackingContext trackingContext;
    private final LensSettings lensSettings;

    private VREyeFramebuffer leftEyeFbo;
    private VREyeFramebuffer rightEyeFbo;

    private final VRHandRenderer handRenderer = new VRHandRenderer();
    private final VRFloatingGuiRenderer guiRenderer = new VRFloatingGuiRenderer();
    private final VRMirrorRenderer mirrorRenderer = new VRMirrorRenderer();

    private int currentEyePass = -1;
    private boolean isRenderingVR = false;

    // Para restaurar estado de Vanilla
    private int prevViewportX, prevViewportY, prevViewportW, prevViewportH;

    public VRRenderEngine(IVRProvider vrProvider, VRTrackingContext trackingContext, LensSettings lensSettings) {
        this.vrProvider = vrProvider;
        this.trackingContext = trackingContext;
        this.lensSettings = lensSettings;
    }

    public void ensureFramebuffers() {
        Minecraft mc = Minecraft.getInstance();
        int targetWidth = (mc != null && mc.getMainRenderTarget() != null) ? mc.getMainRenderTarget().width : 1920;
        int targetHeight = (mc != null && mc.getMainRenderTarget() != null) ? mc.getMainRenderTarget().height : 1080;

        if (this.leftEyeFbo == null) {
            this.leftEyeFbo = new VREyeFramebuffer("Left_Eye", targetWidth, targetHeight);
        } else if (this.leftEyeFbo.getWidth() != targetWidth || this.leftEyeFbo.getHeight() != targetHeight) {
            this.leftEyeFbo.resize(targetWidth, targetHeight);
        }

        if (this.rightEyeFbo == null) {
            this.rightEyeFbo = new VREyeFramebuffer("Right_Eye", targetWidth, targetHeight);
        } else if (this.rightEyeFbo.getWidth() != targetWidth || this.rightEyeFbo.getHeight() != targetHeight) {
            this.rightEyeFbo.resize(targetWidth, targetHeight);
        }

        // Asegura que esten inicializados en GL
        this.leftEyeFbo.ensureInitialized();
        this.rightEyeFbo.ensureInitialized();
    }

    public void onRenderFrameStart() {
        RVVisorMod mod = RVVisorMod.getInstance();
        if (mod == null || !mod.isVrActive()) return;

        // 1. Guarda poses del frame previo para interpolacion
        this.trackingContext.beginNewFrame();

        // 2. Inicio de ciclo en VR provider
        this.vrProvider.beginFrame();

        // 3. Consulta poses del hardware
        this.vrProvider.pollPoses(this.trackingContext);

        // 4. Recalcula posicion de ojos con el IPD actual
        this.trackingContext.onPosesUpdated(this.lensSettings.getIpd());

        if (mod.getControllerInput() != null) {
            mod.getControllerInput().pollControllers();
        }

        this.ensureFramebuffers();
    }

    /**
     * Inicia el render de un ojo manteniendo la resolucion nativa limpia de Minecraft.
     */
    public void beginEyePass(int eye, float partialTicks) {
        this.currentEyePass = eye;
        this.isRenderingVR = true;
        this.trackingContext.updateInterpolatedPoses(partialTicks);

        VREyeFramebuffer fbo = (eye == LensSettings.EYE_LEFT) ? this.leftEyeFbo : this.rightEyeFbo;
        if (fbo != null) {
            fbo.ensureInitialized();
        }

        Minecraft mc = Minecraft.getInstance();
        if (mc != null && mc.getMainRenderTarget() != null) {
            mc.getMainRenderTarget().bindWrite(true);
            RenderSystem.clearColor(0f, 0f, 0f, 1f);
            RenderSystem.clear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT, Minecraft.ON_OSX);
        }
    }

    /**
     * Termina el render del ojo.
     */
    public void endEyePass() {
        this.currentEyePass = -1;
    }

    /**
     * Copia la imagen renderizada en MainRenderTarget al Framebuffer dedicado del ojo para el compositor VR.
     */
    public void copyMainTargetToEyeFbo(int eye, RenderTarget mainTarget) {
        VREyeFramebuffer eyeFbo = (eye == LensSettings.EYE_LEFT) ? this.leftEyeFbo : this.rightEyeFbo;
        if (eyeFbo == null || mainTarget == null) return;

        eyeFbo.ensureInitialized();

        // Blit color buffer de MainRenderTarget -> Eye FBO
        GlStateManager._glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, mainTarget.frameBufferId);
        GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, eyeFbo.getFramebufferId());

        GL30.glBlitFramebuffer(
                0, 0, mainTarget.width, mainTarget.height,
                0, 0, eyeFbo.getWidth(), eyeFbo.getHeight(),
                GL11.GL_COLOR_BUFFER_BIT,
                GL11.GL_LINEAR
        );

        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, 0);
    }

    public void finishAndSubmitFrame(int windowWidth, int windowHeight) {
        if (!this.isRenderingVR) return;

        try {
            // Validar FBOs
            if (this.leftEyeFbo != null && this.leftEyeFbo.isComplete()) {
                this.vrProvider.submitFrame(
                        LensSettings.EYE_LEFT,
                        this.leftEyeFbo.getColorTextureId(),
                        this.leftEyeFbo.getWidth(),
                        this.leftEyeFbo.getHeight()
                );
            }

            if (this.rightEyeFbo != null && this.rightEyeFbo.isComplete()) {
                this.vrProvider.submitFrame(
                        LensSettings.EYE_RIGHT,
                        this.rightEyeFbo.getColorTextureId(),
                        this.rightEyeFbo.getWidth(),
                        this.rightEyeFbo.getHeight()
                );
            }

            this.vrProvider.postSubmit();

            // Mirror al final, usando el main target ya restaurado
            this.mirrorRenderer.renderMirror(this.leftEyeFbo, this.rightEyeFbo, windowWidth, windowHeight);

        } finally {
            this.currentEyePass = -1;
            this.isRenderingVR = false;
        }
    }

    // --- Matrices corregidas ---

    public Matrix4f getEyeProjectionMatrix(float near, float far) {
        if (this.currentEyePass < 0) {
            Minecraft mc = Minecraft.getInstance();
            float aspect = (mc != null && mc.getWindow() != null) ?
                (float) mc.getWindow().getWidth() / (float) mc.getWindow().getHeight() : 16f / 9f;
            return new Matrix4f().perspective((float) Math.toRadians(70.0), aspect, near, far);
        }
        return this.lensSettings.calculateProjectionMatrix(this.currentEyePass, near, far);
    }

    public Matrix4f getEyeViewMatrix(float partialTicks) {
        if (this.currentEyePass < 0 || this.trackingContext == null) {
            return new Matrix4f().identity();
        }
        return this.trackingContext.getEyeViewMatrix(this.currentEyePass);
    }

    public Vector3f getEyePosition(int eye) {
        return this.trackingContext.getEyePosition(eye);
    }

    public int getCurrentEyePass() {
        return this.currentEyePass;
    }

    public boolean isRenderingVR() {
        return this.isRenderingVR;
    }

    public VRHandRenderer getHandRenderer() {
        return this.handRenderer;
    }

    /**
     * Renders 3D World VR Elements (6-DOF Hands, held items, 3D Crosshair, and targeting laser)
     * during the 3D level pass for each eye before GUI/HUD overlays.
     */
    public void renderVRWorldElements(Camera camera, float partialTicks, Matrix4f projectionMatrix) {
        Minecraft mc = Minecraft.getInstance();
        if (mc == null || mc.player == null || mc.level == null) return;

        MultiBufferSource.BufferSource bufferSource = mc.renderBuffers().bufferSource();
        PoseStack poseStack = new PoseStack();

        // 1. Render 6-DOF Hand controllers & held tools/weapons
        int defaultLight = LevelRenderer.getLightColor(mc.level, mc.player.blockPosition());
        this.handRenderer.renderHands(poseStack, bufferSource, defaultLight, partialTicks, this.trackingContext, this.currentEyePass, camera);

        // 2. Render In-World 3D Crosshair
        this.renderCrosshairInWorld(poseStack, bufferSource, camera, partialTicks);

        // Flush buffer source
        bufferSource.endBatch();
    }

    /**
     * Renders an ergonomic 3D In-World Crosshair placed at the exact hit target / raycast location.
     * Eliminates binocular disparity, double vision, and eye strain caused by 2D locked crosshairs.
     */
    public void renderCrosshairInWorld(PoseStack poseStack, MultiBufferSource bufferSource, Camera camera, float partialTicks) {
        Minecraft mc = Minecraft.getInstance();
        if (mc == null || mc.player == null) return;

        // Skip if inside screens / menus or F1 mode
        if (mc.screen != null || mc.options.hideGui) return;

        Vec3 camPos = camera.getPosition();
        Vec3 lookVec = new Vec3(camera.getLookVector().x, camera.getLookVector().y, camera.getLookVector().z);

        // Calculate Hit Target Location
        Vec3 hitPos;
        HitResult hitResult = mc.hitResult;
        boolean hasHit = (hitResult != null && hitResult.getType() != HitResult.Type.MISS);

        if (hasHit) {
            hitPos = hitResult.getLocation();
        } else {
            // Default 6-meter look distance in the world
            hitPos = camPos.add(lookVec.scale(6.0));
        }

        // Push slightly toward camera to avoid block surface z-fighting
        Vec3 toCam = camPos.subtract(hitPos).normalize();
        Vec3 renderPos = hitPos.add(toCam.scale(0.015));

        poseStack.pushPose();

        // 1. Translate to world position relative to camera
        poseStack.translate(renderPos.x - camPos.x, renderPos.y - camPos.y, renderPos.z - camPos.z);

        // 2. Billboard Rotation: Quad faces camera directly
        poseStack.mulPose(Axis.YP.rotationDegrees(-camera.getYRot() + 180.0f));
        poseStack.mulPose(Axis.XP.rotationDegrees(-camera.getXRot()));

        // 3. Dynamic Distance Scaling: Maintains crisp apparent visual size from 0.2m to 100m
        double dist = camPos.distanceTo(renderPos);
        float scale = (float) Math.max(0.005f, Math.min(0.20f, dist * 0.018f));
        poseStack.scale(scale, scale, scale);

        // 4. Draw 3D Crosshair Reticle (Center dot, 4 arms, hit indicator, break progress)
        VertexConsumer consumer = bufferSource.getBuffer(RenderType.gui());
        Matrix4f mat = poseStack.last().pose();

        float r = 1.0f, g = 1.0f, b = 1.0f, a = 0.9f;
        if (hasHit && hitResult.getType() == HitResult.Type.ENTITY) {
            r = 1.0f; g = 0.25f; b = 0.25f; // Red when targeting entity
        } else if (hasHit && hitResult.getType() == HitResult.Type.BLOCK) {
            r = 0.35f; g = 0.85f; b = 1.0f; // Cyan when targeting block
        }

        // Center dot
        drawSolidQuad(consumer, mat, -0.05f, -0.05f, 0.05f, 0.05f, 0.0f, r, g, b, 1.0f);

        // 4 Crosshair Reticle Bars
        float inner = 0.10f;
        float outer = 0.35f;
        float thickness = 0.04f;

        // Top bar
        drawSolidQuad(consumer, mat, -thickness * 0.5f, inner, thickness * 0.5f, outer, 0.0f, r, g, b, a);
        // Bottom bar
        drawSolidQuad(consumer, mat, -thickness * 0.5f, -outer, thickness * 0.5f, -inner, 0.0f, r, g, b, a);
        // Left bar
        drawSolidQuad(consumer, mat, -outer, -thickness * 0.5f, -inner, thickness * 0.5f, 0.0f, r, g, b, a);
        // Right bar
        drawSolidQuad(consumer, mat, inner, -thickness * 0.5f, outer, thickness * 0.5f, 0.0f, r, g, b, a);

        // Mining Progress Indicator
        if (mc.gameMode != null && mc.gameMode.isDestroying()) {
            float ringSize = 0.45f;
            // Yellow/Orange progress ring indicating active block mining
            drawSolidQuad(consumer, mat, -ringSize, -ringSize, ringSize, -ringSize + 0.06f, 0.0f, 1.0f, 0.8f, 0.1f, 0.95f);
        }

        // Attack Cooldown Indicator
        if (mc.player != null) {
            float attackCooldown = mc.player.getAttackStrengthScale(0.0f);
            if (attackCooldown < 0.99f) {
                float barW = 0.30f;
                float barH = 0.04f;
                float yPos = -0.50f;
                // Background dark bar
                drawSolidQuad(consumer, mat, -barW, yPos, barW, yPos + barH, 0.0f, 0.0f, 0.0f, 0.0f, 0.5f);
                // Filled cooldown bar
                drawSolidQuad(consumer, mat, -barW, yPos, -barW + (barW * 2.0f * attackCooldown), yPos + barH, 0.0f, 1.0f, 1.0f, 1.0f, 0.9f);
            }
        }

        poseStack.popPose();
    }

    private void drawSolidQuad(VertexConsumer consumer, Matrix4f mat, float minX, float minY, float maxX, float maxY, float z,
                               float r, float g, float b, float a) {
        consumer.addVertex(mat, minX, minY, z).setColor(r, g, b, a);
        consumer.addVertex(mat, maxX, minY, z).setColor(r, g, b, a);
        consumer.addVertex(mat, maxX, maxY, z).setColor(r, g, b, a);
        consumer.addVertex(mat, minX, maxY, z).setColor(r, g, b, a);
    }

    public VRFloatingGuiRenderer getGuiRenderer() {
        return this.guiRenderer;
    }

    public VRMirrorRenderer getMirrorRenderer() {
        return this.mirrorRenderer;
    }

    public VREyeFramebuffer getLeftEyeFbo() {
        return this.leftEyeFbo;
    }

    public VREyeFramebuffer getRightEyeFbo() {
        return this.rightEyeFbo;
    }

    public void destroy() {
        if (this.leftEyeFbo != null) {
            this.leftEyeFbo.destroy();
            this.leftEyeFbo = null;
        }
        if (this.rightEyeFbo != null) {
            this.rightEyeFbo.destroy();
            this.rightEyeFbo = null;
        }
    }
}
