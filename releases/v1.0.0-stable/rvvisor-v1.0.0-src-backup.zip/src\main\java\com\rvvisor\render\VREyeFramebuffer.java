package com.rvvisor.render;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL30;

/**
 * Dedicated high-performance offscreen framebuffer for VR eye views.
 * Creates both native RGBA8 color texture and 24-bit Depth Texture (GL_DEPTH_ATTACHMENT)
 * ensuring translucent water shaders, depth testing, and fog render with pixel-perfect accuracy.
 */
public class VREyeFramebuffer {
    private final String name;
    private int width;
    private int height;

    private int framebufferId = -1;
    private int colorTextureId = -1;
    private int depthTextureId = -1;

    public VREyeFramebuffer(String name, int width, int height) {
        this.name = name;
        this.width = width;
        this.height = height;
    }

    public void ensureInitialized() {
        if (this.framebufferId != -1) return;
        this.init();
    }

    public void init() {
        RenderSystem.assertOnRenderThreadOrInit();
        this.destroy();

        // 1. Generate FBO
        this.framebufferId = GlStateManager.glGenFramebuffers();
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, this.framebufferId);

        // 2. Generate Color Texture (RGBA8)
        this.colorTextureId = GlStateManager._genTexture();
        GlStateManager._bindTexture(this.colorTextureId);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL12.GL_CLAMP_TO_EDGE);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL12.GL_CLAMP_TO_EDGE);
        GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA8, this.width, this.height, 0, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, (java.nio.ByteBuffer) null);
        GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, this.colorTextureId, 0);

        // 3. Generate Depth Texture (24-bit Depth Component for Water & Translucent Depth Testing)
        this.depthTextureId = GlStateManager._genTexture();
        GlStateManager._bindTexture(this.depthTextureId);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_NEAREST);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_NEAREST);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL14.GL_TEXTURE_COMPARE_MODE, GL14.GL_NONE);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL12.GL_CLAMP_TO_EDGE);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL12.GL_CLAMP_TO_EDGE);
        GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL14.GL_DEPTH_COMPONENT24, this.width, this.height, 0, GL11.GL_DEPTH_COMPONENT, GL11.GL_FLOAT, (java.nio.ByteBuffer) null);
        GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_DEPTH_ATTACHMENT, GL11.GL_TEXTURE_2D, this.depthTextureId, 0);

        // 4. Validate Complete FBO
        int status = GL30.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER);
        if (status != GL30.GL_FRAMEBUFFER_COMPLETE) {
            GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, 0);
            this.destroy();
            throw new RuntimeException("FBO [" + this.name + "] incomplete: " + status);
        }

        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, 0);
        GlStateManager._bindTexture(0);
    }

    public void bindWrite(boolean setViewport) {
        this.ensureInitialized();
        RenderSystem.assertOnRenderThread();
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, this.framebufferId);
        if (setViewport) {
            GlStateManager._viewport(0, 0, this.width, this.height);
        }
    }

    public void unbindWrite() {
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, 0);
    }

    public void clear(float r, float g, float b, float a) {
        this.bindWrite(true);
        RenderSystem.clearColor(r, g, b, a);
        RenderSystem.clear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT, Minecraft.ON_OSX);
    }

    public boolean isComplete() {
        if (this.framebufferId == -1) return false;
        int prevFbo = GL11.glGetInteger(GL30.GL_FRAMEBUFFER_BINDING);
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, this.framebufferId);
        boolean complete = GL30.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER) == GL30.GL_FRAMEBUFFER_COMPLETE;
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, prevFbo);
        return complete;
    }

    public void resize(int newWidth, int newHeight) {
        if (this.width == newWidth && this.height == newHeight) return;
        RenderSystem.assertOnRenderThreadOrInit();
        if (GL11.glGetInteger(GL30.GL_FRAMEBUFFER_BINDING) == this.framebufferId) {
            GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, 0);
        }
        this.width = newWidth;
        this.height = newHeight;
        this.init();
    }

    public void bind() {
        this.bindWrite(false);
    }

    public void unbind() {
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, 0);
    }

    public int getFramebufferId() {
        return this.framebufferId;
    }

    public int getColorTextureId() {
        return this.colorTextureId;
    }

    public int getDepthTextureId() {
        return this.depthTextureId;
    }

    public int getWidth() {
        return this.width;
    }

    public int getHeight() {
        return this.height;
    }

    public String getName() {
        return this.name;
    }

    public void destroy() {
        RenderSystem.assertOnRenderThreadOrInit();
        if (this.framebufferId != -1) {
            if (GL11.glGetInteger(GL30.GL_FRAMEBUFFER_BINDING) == this.framebufferId) {
                GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, 0);
            }
        }
        if (this.colorTextureId != -1) {
            GlStateManager._deleteTexture(this.colorTextureId);
            this.colorTextureId = -1;
        }
        if (this.depthTextureId != -1) {
            GlStateManager._deleteTexture(this.depthTextureId);
            this.depthTextureId = -1;
        }
        if (this.framebufferId != -1) {
            GlStateManager._glDeleteFramebuffers(this.framebufferId);
            this.framebufferId = -1;
        }
    }
}
