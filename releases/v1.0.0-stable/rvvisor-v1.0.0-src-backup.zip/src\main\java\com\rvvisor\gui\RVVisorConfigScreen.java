package com.rvvisor.gui;

import com.rvvisor.core.optics.LensSettings;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class RVVisorConfigScreen extends Screen {
    private final Screen parent;
    private final LensSettings settings;

    public RVVisorConfigScreen(Screen parent, LensSettings settings) {
        super(Component.literal("RV-Visor Config"));
        this.parent = parent;
        this.settings = settings;
    }

    @Override
    protected void init() {
        this.addRenderableWidget(Button.builder(
            Component.literal("Res: " + this.settings.getEffectiveWidth() + "x" + this.settings.getEffectiveHeight() + " [" + String.format("%.1f", this.settings.getSupersamplingScale()) + "x]"),
            b -> {
                float next = (float) (Math.round((this.settings.getSupersamplingScale() + 0.1f) * 10.0) / 10.0);
                if (next > 3.0f) next = 0.5f;
                this.settings.setSupersamplingScale(next);
                b.setMessage(Component.literal("Res: " + this.settings.getEffectiveWidth() + "x" + this.settings.getEffectiveHeight() + " [" + String.format("%.1f", this.settings.getSupersamplingScale()) + "x]"));
            }
        ).bounds(this.width / 2 - 100, this.height / 2 - 10, 200, 20).build());

        this.addRenderableWidget(Button.builder(Component.literal("Hecho"), b -> this.onClose())
            .bounds(this.width / 2 - 100, this.height / 2 + 20, 200, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        super.render(g, mouseX, mouseY, delta);
        g.drawCenteredString(this.font, "RV-Visor - Numpad + / - para cambiar en juego", this.width / 2, this.height / 2 - 40, 0xFFFFFF);
    }

    @Override
    public void onClose() {
        if (this.minecraft != null) {
            this.minecraft.setScreen(this.parent);
        }
    }
}
