package com.rvvisor.core.optics;

import org.joml.Matrix4f;

/**
 * High-performance Lens Resolution & Optical Configuration Engine.
 * Supports per-eye resolutions, dynamic supersampling, IPD adjustment,
 * and asymmetric frustum projection matching OpenVR / SteamVR optics.
 */
public class LensSettings {
    public static final int EYE_LEFT = 0;
    public static final int EYE_RIGHT = 1;

    // Per-eye base physical resolution (e.g. 2160x2160 for Quest 3 / Reverb G2)
    private int baseWidth = 2160;
    private int baseHeight = 2160;

    // Supersampling multiplier (1.0 = native, 1.4 = recommended VR standard, 1.7-2.0 = Ultra crisp)
    private float supersamplingScale = 1.4f;

    // Interpupillary Distance (IPD) in meters (default: 63mm = 0.063m)
    private float ipd = 0.063f;

    // Asymmetric FOV tangents (tan of angles from optical center in OpenVR format)
    // Left Eye (Wider FOV to fix "zoomed in" feeling)
    private float leftEyeFovLeft = -1.2f;
    private float leftEyeFovRight = 1.2f;
    private float leftEyeFovUp = -1.2f; // OpenVR top is negative
    private float leftEyeFovDown = 1.2f; // OpenVR bottom is positive

    // Right Eye
    private float rightEyeFovLeft = -1.2f;
    private float rightEyeFovRight = 1.2f;
    private float rightEyeFovUp = -1.2f;
    private float rightEyeFovDown = 1.2f;

    // Lens distortion coefficients
    private float distortionK1 = 0.0f;
    private float distortionK2 = 0.0f;

    // Near and far clipping planes (Vivecraft standard nearClip is 0.02f to prevent close-up ghosting)
    private float nearClip = 0.02f;
    private float farClip = 1000.0f;

    public void loadDefaults() {
        this.baseWidth = 2160;
        this.baseHeight = 2160;
        this.supersamplingScale = 1.4f;
        this.ipd = 0.063f;

        this.leftEyeFovLeft = -1.0f;
        this.leftEyeFovRight = 1.0f;
        this.leftEyeFovUp = -1.0f;
        this.leftEyeFovDown = 1.0f;

        this.rightEyeFovLeft = -1.0f;
        this.rightEyeFovRight = 1.0f;
        this.rightEyeFovUp = -1.0f;
        this.rightEyeFovDown = 1.0f;
    }

    public void applyHardwareDefaults(LensSettings hardware) {
        if (hardware == null) return;
        if (hardware.baseWidth > 0) this.baseWidth = hardware.baseWidth;
        if (hardware.baseHeight > 0) this.baseHeight = hardware.baseHeight;
        if (hardware.ipd > 0.04f && hardware.ipd < 0.09f) this.ipd = hardware.ipd;
        this.leftEyeFovLeft = hardware.leftEyeFovLeft;
        this.leftEyeFovRight = hardware.leftEyeFovRight;
        this.leftEyeFovUp = hardware.leftEyeFovUp;
        this.leftEyeFovDown = hardware.leftEyeFovDown;
        this.rightEyeFovLeft = hardware.rightEyeFovLeft;
        this.rightEyeFovRight = hardware.rightEyeFovRight;
        this.rightEyeFovUp = hardware.rightEyeFovUp;
        this.rightEyeFovDown = hardware.rightEyeFovDown;
    }

    public int getEffectiveWidth() {
        return Math.max(256, Math.round(this.baseWidth * this.supersamplingScale));
    }

    public int getEffectiveHeight() {
        return Math.max(256, Math.round(this.baseHeight * this.supersamplingScale));
    }

    public int getBaseWidth() {
        return this.baseWidth;
    }

    public void setBaseWidth(int baseWidth) {
        this.baseWidth = Math.max(256, baseWidth);
    }

    public int getBaseHeight() {
        return this.baseHeight;
    }

    public void setBaseHeight(int baseHeight) {
        this.baseHeight = Math.max(256, baseHeight);
    }

    public float getSupersamplingScale() {
        return this.supersamplingScale;
    }

    public void setSupersamplingScale(float scale) {
        this.supersamplingScale = Math.max(0.25f, Math.min(3.0f, scale));
    }

    public void stepSupersamplingUp() {
        this.setSupersamplingScale(Math.min(3.0f, (float) (Math.round((this.supersamplingScale + 0.1f) * 10.0) / 10.0)));
    }

    public void stepSupersamplingDown() {
        this.setSupersamplingScale(Math.max(0.5f, (float) (Math.round((this.supersamplingScale - 0.1f) * 10.0) / 10.0)));
    }

    public float getIpd() {
        return this.ipd;
    }

    public void setIpd(float ipdMeters) {
        this.ipd = Math.max(0.045f, Math.min(0.085f, ipdMeters));
    }

    public void setCustomResolution(int width, int height, float supersampling) {
        this.setBaseWidth(width);
        this.setBaseHeight(height);
        this.setSupersamplingScale(supersampling);
    }

    public void setFovTangents(int eye, float left, float right, float top, float bottom) {
        if (eye == EYE_LEFT) {
            this.leftEyeFovLeft = left;
            this.leftEyeFovRight = right;
            this.leftEyeFovUp = top;
            this.leftEyeFovDown = bottom;
        } else {
            this.rightEyeFovLeft = left;
            this.rightEyeFovRight = right;
            this.rightEyeFovUp = top;
            this.rightEyeFovDown = bottom;
        }
    }

    /**
     * Calculates the asymmetric frustum projection matrix for the specified eye.
     * Matches OpenVR/SteamVR projection tangent bounds.
     */
    public Matrix4f calculateProjectionMatrix(int eye, float zNear, float zFar) {
        float l = (eye == EYE_LEFT) ? this.leftEyeFovLeft : this.rightEyeFovLeft;
        float r = (eye == EYE_LEFT) ? this.leftEyeFovRight : this.rightEyeFovRight;
        float top = (eye == EYE_LEFT) ? this.leftEyeFovUp : this.rightEyeFovUp;
        float bottom = (eye == EYE_LEFT) ? this.leftEyeFovDown : this.rightEyeFovDown;

        float jomlLeft = l * zNear;
        float jomlRight = r * zNear;
        float jomlBottom = top * zNear;
        float jomlTop = bottom * zNear;

        return new Matrix4f().frustum(
                jomlLeft,
                jomlRight,
                jomlBottom,
                jomlTop,
                zNear,
                zFar,
                false
        );
    }

    public float getNearClip() {
        return this.nearClip;
    }

    public void setNearClip(float nearClip) {
        this.nearClip = nearClip;
    }

    public float getFarClip() {
        return this.farClip;
    }

    public void setFarClip(float farClip) {
        this.farClip = farClip;
    }

    public float getDistortionK1() {
        return this.distortionK1;
    }

    public float getDistortionK2() {
        return this.distortionK2;
    }
}
