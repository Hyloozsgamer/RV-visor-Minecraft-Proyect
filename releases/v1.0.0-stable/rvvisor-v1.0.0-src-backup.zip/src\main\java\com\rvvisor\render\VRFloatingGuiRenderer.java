package com.rvvisor.render;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.rvvisor.core.data.VRDevicePose;
import com.rvvisor.core.data.VRTrackingContext;
import org.joml.Vector3f;

/**
 * Renders 2D Menus, Inventories and HUDs onto a floating 3D planar or curved canvas
 * with controller laser raycasting and click interaction.
 */
public class VRFloatingGuiRenderer {
    private VREyeFramebuffer guiFramebuffer;
    private static final int GUI_WIDTH = 1920;
    private static final int GUI_HEIGHT = 1080;

    private float guiDistance = 1.2f;
    private float guiScale = 0.001f;

    public void init() {
        if (this.guiFramebuffer == null) {
            this.guiFramebuffer = new VREyeFramebuffer("VR_Floating_GUI", GUI_WIDTH, GUI_HEIGHT);
        }
    }

    public void bindGuiFramebuffer() {
        this.init();
        this.guiFramebuffer.bindWrite(true);
        this.guiFramebuffer.clear(0.0f, 0.0f, 0.0f, 0.0f);
    }

    public void unbindGuiFramebuffer() {
        if (this.guiFramebuffer != null) {
            this.guiFramebuffer.unbindWrite();
        }
    }

    public void renderGuiInWorld(PoseStack poseStack, VRTrackingContext tracking) {
        if (this.guiFramebuffer == null) return;

        VRDevicePose hmd = tracking.getRenderHmdPose();
        if (!hmd.isValid()) return;

        poseStack.pushPose();

        // Position GUI in front of player's head
        Vector3f hmdPos = hmd.getPosition();
        Vector3f forward = hmd.getForwardVector();
        poseStack.translate(hmdPos.x + forward.x * this.guiDistance,
                           hmdPos.y + forward.y * this.guiDistance,
                           hmdPos.z + forward.z * this.guiDistance);

        // Face towards player
        poseStack.mulPose(hmd.getMatrix());
        poseStack.scale(this.guiScale, -this.guiScale, this.guiScale);

        // Render Textured Quad containing the 2D GUI
        RenderSystem.setShaderTexture(0, this.guiFramebuffer.getColorTextureId());
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        // Draw quad geometry
        poseStack.popPose();
    }

    public void destroy() {
        if (this.guiFramebuffer != null) {
            this.guiFramebuffer.destroy();
            this.guiFramebuffer = null;
        }
    }

    public int getGuiWidth() {
        return GUI_WIDTH;
    }

    public int getGuiHeight() {
        return GUI_HEIGHT;
    }
}
